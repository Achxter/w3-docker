<template>
  <div id="text">Selamat Docker Telah Berhasil Dibuat</div>
</template>

<style>
#text {
  width: auto;
  font-size: 100px;
  color: yellow;
}
</style>
